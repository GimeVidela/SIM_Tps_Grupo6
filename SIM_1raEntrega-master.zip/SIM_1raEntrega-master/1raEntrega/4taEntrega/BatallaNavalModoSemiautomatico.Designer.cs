﻿namespace _4taEntrega
{
    partial class BatallaNavalModoSemiautomatico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.p110 = new System.Windows.Forms.PictureBox();
            this.p111 = new System.Windows.Forms.PictureBox();
            this.p112 = new System.Windows.Forms.PictureBox();
            this.p113 = new System.Windows.Forms.PictureBox();
            this.p114 = new System.Windows.Forms.PictureBox();
            this.p115 = new System.Windows.Forms.PictureBox();
            this.p120 = new System.Windows.Forms.PictureBox();
            this.p121 = new System.Windows.Forms.PictureBox();
            this.p122 = new System.Windows.Forms.PictureBox();
            this.p123 = new System.Windows.Forms.PictureBox();
            this.p124 = new System.Windows.Forms.PictureBox();
            this.p125 = new System.Windows.Forms.PictureBox();
            this.f110 = new System.Windows.Forms.PictureBox();
            this.f111 = new System.Windows.Forms.PictureBox();
            this.f112 = new System.Windows.Forms.PictureBox();
            this.f113 = new System.Windows.Forms.PictureBox();
            this.f114 = new System.Windows.Forms.PictureBox();
            this.f120 = new System.Windows.Forms.PictureBox();
            this.f121 = new System.Windows.Forms.PictureBox();
            this.f124 = new System.Windows.Forms.PictureBox();
            this.f122 = new System.Windows.Forms.PictureBox();
            this.f123 = new System.Windows.Forms.PictureBox();
            this.s110 = new System.Windows.Forms.PictureBox();
            this.s120 = new System.Windows.Forms.PictureBox();
            this.s111 = new System.Windows.Forms.PictureBox();
            this.s112 = new System.Windows.Forms.PictureBox();
            this.s113 = new System.Windows.Forms.PictureBox();
            this.s121 = new System.Windows.Forms.PictureBox();
            this.s122 = new System.Windows.Forms.PictureBox();
            this.s123 = new System.Windows.Forms.PictureBox();
            this.c110 = new System.Windows.Forms.PictureBox();
            this.c111 = new System.Windows.Forms.PictureBox();
            this.c112 = new System.Windows.Forms.PictureBox();
            this.c120 = new System.Windows.Forms.PictureBox();
            this.c121 = new System.Windows.Forms.PictureBox();
            this.c122 = new System.Windows.Forms.PictureBox();
            this.d110 = new System.Windows.Forms.PictureBox();
            this.d111 = new System.Windows.Forms.PictureBox();
            this.d120 = new System.Windows.Forms.PictureBox();
            this.d121 = new System.Windows.Forms.PictureBox();
            this.d221 = new System.Windows.Forms.PictureBox();
            this.d220 = new System.Windows.Forms.PictureBox();
            this.d211 = new System.Windows.Forms.PictureBox();
            this.d210 = new System.Windows.Forms.PictureBox();
            this.c222 = new System.Windows.Forms.PictureBox();
            this.c221 = new System.Windows.Forms.PictureBox();
            this.c220 = new System.Windows.Forms.PictureBox();
            this.c212 = new System.Windows.Forms.PictureBox();
            this.c211 = new System.Windows.Forms.PictureBox();
            this.c210 = new System.Windows.Forms.PictureBox();
            this.s223 = new System.Windows.Forms.PictureBox();
            this.s222 = new System.Windows.Forms.PictureBox();
            this.s221 = new System.Windows.Forms.PictureBox();
            this.s213 = new System.Windows.Forms.PictureBox();
            this.s212 = new System.Windows.Forms.PictureBox();
            this.s211 = new System.Windows.Forms.PictureBox();
            this.s220 = new System.Windows.Forms.PictureBox();
            this.s210 = new System.Windows.Forms.PictureBox();
            this.f223 = new System.Windows.Forms.PictureBox();
            this.f222 = new System.Windows.Forms.PictureBox();
            this.f224 = new System.Windows.Forms.PictureBox();
            this.f221 = new System.Windows.Forms.PictureBox();
            this.f220 = new System.Windows.Forms.PictureBox();
            this.f214 = new System.Windows.Forms.PictureBox();
            this.f213 = new System.Windows.Forms.PictureBox();
            this.f212 = new System.Windows.Forms.PictureBox();
            this.f211 = new System.Windows.Forms.PictureBox();
            this.f210 = new System.Windows.Forms.PictureBox();
            this.p225 = new System.Windows.Forms.PictureBox();
            this.p224 = new System.Windows.Forms.PictureBox();
            this.p223 = new System.Windows.Forms.PictureBox();
            this.p222 = new System.Windows.Forms.PictureBox();
            this.p221 = new System.Windows.Forms.PictureBox();
            this.p220 = new System.Windows.Forms.PictureBox();
            this.p215 = new System.Windows.Forms.PictureBox();
            this.p214 = new System.Windows.Forms.PictureBox();
            this.p213 = new System.Windows.Forms.PictureBox();
            this.p212 = new System.Windows.Forms.PictureBox();
            this.p211 = new System.Windows.Forms.PictureBox();
            this.p210 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.listaJugador2 = new System.Windows.Forms.ListBox();
            this.listaJugador1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.p110)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p111)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p112)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p113)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p114)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p115)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p120)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p121)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p122)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p123)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p124)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p125)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f110)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f111)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f112)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f113)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f114)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f120)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f121)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f124)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f122)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f123)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s110)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s120)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s111)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s112)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s113)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s121)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s122)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s123)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c110)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c111)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c112)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c120)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c121)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c122)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.d110)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.d111)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.d120)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.d121)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.d221)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.d220)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.d211)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.d210)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c222)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c221)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c220)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c212)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c211)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c210)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s223)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s222)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s221)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s213)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s212)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s211)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s220)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s210)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f223)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f222)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f224)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f221)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f220)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f214)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f213)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f212)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f211)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f210)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p225)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p224)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p223)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p222)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p221)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p220)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p215)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p214)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p213)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p212)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p211)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p210)).BeginInit();
            this.SuspendLayout();
            // 
            // p110
            // 
            this.p110.BackColor = System.Drawing.Color.Lime;
            this.p110.Location = new System.Drawing.Point(12, 12);
            this.p110.Name = "p110";
            this.p110.Size = new System.Drawing.Size(50, 50);
            this.p110.TabIndex = 0;
            this.p110.TabStop = false;
            // 
            // p111
            // 
            this.p111.BackColor = System.Drawing.Color.Lime;
            this.p111.Location = new System.Drawing.Point(68, 12);
            this.p111.Name = "p111";
            this.p111.Size = new System.Drawing.Size(50, 50);
            this.p111.TabIndex = 1;
            this.p111.TabStop = false;
            // 
            // p112
            // 
            this.p112.BackColor = System.Drawing.Color.Lime;
            this.p112.Location = new System.Drawing.Point(124, 12);
            this.p112.Name = "p112";
            this.p112.Size = new System.Drawing.Size(50, 50);
            this.p112.TabIndex = 2;
            this.p112.TabStop = false;
            // 
            // p113
            // 
            this.p113.BackColor = System.Drawing.Color.Lime;
            this.p113.Location = new System.Drawing.Point(180, 12);
            this.p113.Name = "p113";
            this.p113.Size = new System.Drawing.Size(50, 50);
            this.p113.TabIndex = 3;
            this.p113.TabStop = false;
            // 
            // p114
            // 
            this.p114.BackColor = System.Drawing.Color.Lime;
            this.p114.Location = new System.Drawing.Point(236, 12);
            this.p114.Name = "p114";
            this.p114.Size = new System.Drawing.Size(50, 50);
            this.p114.TabIndex = 4;
            this.p114.TabStop = false;
            // 
            // p115
            // 
            this.p115.BackColor = System.Drawing.Color.Lime;
            this.p115.Location = new System.Drawing.Point(292, 12);
            this.p115.Name = "p115";
            this.p115.Size = new System.Drawing.Size(50, 50);
            this.p115.TabIndex = 5;
            this.p115.TabStop = false;
            // 
            // p120
            // 
            this.p120.BackColor = System.Drawing.Color.Lime;
            this.p120.Location = new System.Drawing.Point(12, 68);
            this.p120.Name = "p120";
            this.p120.Size = new System.Drawing.Size(50, 50);
            this.p120.TabIndex = 6;
            this.p120.TabStop = false;
            // 
            // p121
            // 
            this.p121.BackColor = System.Drawing.Color.Lime;
            this.p121.Location = new System.Drawing.Point(68, 68);
            this.p121.Name = "p121";
            this.p121.Size = new System.Drawing.Size(50, 50);
            this.p121.TabIndex = 7;
            this.p121.TabStop = false;
            // 
            // p122
            // 
            this.p122.BackColor = System.Drawing.Color.Lime;
            this.p122.Location = new System.Drawing.Point(124, 68);
            this.p122.Name = "p122";
            this.p122.Size = new System.Drawing.Size(50, 50);
            this.p122.TabIndex = 8;
            this.p122.TabStop = false;
            // 
            // p123
            // 
            this.p123.BackColor = System.Drawing.Color.Lime;
            this.p123.Location = new System.Drawing.Point(180, 68);
            this.p123.Name = "p123";
            this.p123.Size = new System.Drawing.Size(50, 50);
            this.p123.TabIndex = 9;
            this.p123.TabStop = false;
            // 
            // p124
            // 
            this.p124.BackColor = System.Drawing.Color.Lime;
            this.p124.Location = new System.Drawing.Point(236, 68);
            this.p124.Name = "p124";
            this.p124.Size = new System.Drawing.Size(50, 50);
            this.p124.TabIndex = 10;
            this.p124.TabStop = false;
            // 
            // p125
            // 
            this.p125.BackColor = System.Drawing.Color.Lime;
            this.p125.Location = new System.Drawing.Point(292, 68);
            this.p125.Name = "p125";
            this.p125.Size = new System.Drawing.Size(50, 50);
            this.p125.TabIndex = 11;
            this.p125.TabStop = false;
            // 
            // f110
            // 
            this.f110.BackColor = System.Drawing.Color.Lime;
            this.f110.Location = new System.Drawing.Point(12, 124);
            this.f110.Name = "f110";
            this.f110.Size = new System.Drawing.Size(50, 50);
            this.f110.TabIndex = 12;
            this.f110.TabStop = false;
            // 
            // f111
            // 
            this.f111.BackColor = System.Drawing.Color.Lime;
            this.f111.Location = new System.Drawing.Point(68, 124);
            this.f111.Name = "f111";
            this.f111.Size = new System.Drawing.Size(50, 50);
            this.f111.TabIndex = 13;
            this.f111.TabStop = false;
            // 
            // f112
            // 
            this.f112.BackColor = System.Drawing.Color.Lime;
            this.f112.Location = new System.Drawing.Point(124, 124);
            this.f112.Name = "f112";
            this.f112.Size = new System.Drawing.Size(50, 50);
            this.f112.TabIndex = 14;
            this.f112.TabStop = false;
            // 
            // f113
            // 
            this.f113.BackColor = System.Drawing.Color.Lime;
            this.f113.Location = new System.Drawing.Point(180, 124);
            this.f113.Name = "f113";
            this.f113.Size = new System.Drawing.Size(50, 50);
            this.f113.TabIndex = 15;
            this.f113.TabStop = false;
            // 
            // f114
            // 
            this.f114.BackColor = System.Drawing.Color.Lime;
            this.f114.Location = new System.Drawing.Point(236, 124);
            this.f114.Name = "f114";
            this.f114.Size = new System.Drawing.Size(50, 50);
            this.f114.TabIndex = 16;
            this.f114.TabStop = false;
            // 
            // f120
            // 
            this.f120.BackColor = System.Drawing.Color.Lime;
            this.f120.Location = new System.Drawing.Point(12, 180);
            this.f120.Name = "f120";
            this.f120.Size = new System.Drawing.Size(50, 50);
            this.f120.TabIndex = 17;
            this.f120.TabStop = false;
            // 
            // f121
            // 
            this.f121.BackColor = System.Drawing.Color.Lime;
            this.f121.Location = new System.Drawing.Point(68, 180);
            this.f121.Name = "f121";
            this.f121.Size = new System.Drawing.Size(50, 50);
            this.f121.TabIndex = 18;
            this.f121.TabStop = false;
            // 
            // f124
            // 
            this.f124.BackColor = System.Drawing.Color.Lime;
            this.f124.Location = new System.Drawing.Point(236, 180);
            this.f124.Name = "f124";
            this.f124.Size = new System.Drawing.Size(50, 50);
            this.f124.TabIndex = 19;
            this.f124.TabStop = false;
            // 
            // f122
            // 
            this.f122.BackColor = System.Drawing.Color.Lime;
            this.f122.Location = new System.Drawing.Point(124, 180);
            this.f122.Name = "f122";
            this.f122.Size = new System.Drawing.Size(50, 50);
            this.f122.TabIndex = 19;
            this.f122.TabStop = false;
            // 
            // f123
            // 
            this.f123.BackColor = System.Drawing.Color.Lime;
            this.f123.Location = new System.Drawing.Point(180, 180);
            this.f123.Name = "f123";
            this.f123.Size = new System.Drawing.Size(50, 50);
            this.f123.TabIndex = 20;
            this.f123.TabStop = false;
            // 
            // s110
            // 
            this.s110.BackColor = System.Drawing.Color.Lime;
            this.s110.Location = new System.Drawing.Point(12, 236);
            this.s110.Name = "s110";
            this.s110.Size = new System.Drawing.Size(50, 50);
            this.s110.TabIndex = 21;
            this.s110.TabStop = false;
            // 
            // s120
            // 
            this.s120.BackColor = System.Drawing.Color.Lime;
            this.s120.Location = new System.Drawing.Point(12, 292);
            this.s120.Name = "s120";
            this.s120.Size = new System.Drawing.Size(50, 50);
            this.s120.TabIndex = 22;
            this.s120.TabStop = false;
            // 
            // s111
            // 
            this.s111.BackColor = System.Drawing.Color.Lime;
            this.s111.Location = new System.Drawing.Point(68, 236);
            this.s111.Name = "s111";
            this.s111.Size = new System.Drawing.Size(50, 50);
            this.s111.TabIndex = 23;
            this.s111.TabStop = false;
            // 
            // s112
            // 
            this.s112.BackColor = System.Drawing.Color.Lime;
            this.s112.Location = new System.Drawing.Point(124, 236);
            this.s112.Name = "s112";
            this.s112.Size = new System.Drawing.Size(50, 50);
            this.s112.TabIndex = 24;
            this.s112.TabStop = false;
            // 
            // s113
            // 
            this.s113.BackColor = System.Drawing.Color.Lime;
            this.s113.Location = new System.Drawing.Point(180, 236);
            this.s113.Name = "s113";
            this.s113.Size = new System.Drawing.Size(50, 50);
            this.s113.TabIndex = 25;
            this.s113.TabStop = false;
            // 
            // s121
            // 
            this.s121.BackColor = System.Drawing.Color.Lime;
            this.s121.Location = new System.Drawing.Point(68, 292);
            this.s121.Name = "s121";
            this.s121.Size = new System.Drawing.Size(50, 50);
            this.s121.TabIndex = 26;
            this.s121.TabStop = false;
            // 
            // s122
            // 
            this.s122.BackColor = System.Drawing.Color.Lime;
            this.s122.Location = new System.Drawing.Point(124, 292);
            this.s122.Name = "s122";
            this.s122.Size = new System.Drawing.Size(50, 50);
            this.s122.TabIndex = 27;
            this.s122.TabStop = false;
            // 
            // s123
            // 
            this.s123.BackColor = System.Drawing.Color.Lime;
            this.s123.Location = new System.Drawing.Point(180, 292);
            this.s123.Name = "s123";
            this.s123.Size = new System.Drawing.Size(50, 50);
            this.s123.TabIndex = 28;
            this.s123.TabStop = false;
            // 
            // c110
            // 
            this.c110.BackColor = System.Drawing.Color.Lime;
            this.c110.Location = new System.Drawing.Point(12, 348);
            this.c110.Name = "c110";
            this.c110.Size = new System.Drawing.Size(50, 50);
            this.c110.TabIndex = 29;
            this.c110.TabStop = false;
            // 
            // c111
            // 
            this.c111.BackColor = System.Drawing.Color.Lime;
            this.c111.Location = new System.Drawing.Point(68, 348);
            this.c111.Name = "c111";
            this.c111.Size = new System.Drawing.Size(50, 50);
            this.c111.TabIndex = 30;
            this.c111.TabStop = false;
            // 
            // c112
            // 
            this.c112.BackColor = System.Drawing.Color.Lime;
            this.c112.Location = new System.Drawing.Point(124, 348);
            this.c112.Name = "c112";
            this.c112.Size = new System.Drawing.Size(50, 50);
            this.c112.TabIndex = 31;
            this.c112.TabStop = false;
            // 
            // c120
            // 
            this.c120.BackColor = System.Drawing.Color.Lime;
            this.c120.Location = new System.Drawing.Point(12, 404);
            this.c120.Name = "c120";
            this.c120.Size = new System.Drawing.Size(50, 50);
            this.c120.TabIndex = 32;
            this.c120.TabStop = false;
            // 
            // c121
            // 
            this.c121.BackColor = System.Drawing.Color.Lime;
            this.c121.Location = new System.Drawing.Point(68, 404);
            this.c121.Name = "c121";
            this.c121.Size = new System.Drawing.Size(50, 50);
            this.c121.TabIndex = 33;
            this.c121.TabStop = false;
            // 
            // c122
            // 
            this.c122.BackColor = System.Drawing.Color.Lime;
            this.c122.Location = new System.Drawing.Point(124, 404);
            this.c122.Name = "c122";
            this.c122.Size = new System.Drawing.Size(50, 50);
            this.c122.TabIndex = 34;
            this.c122.TabStop = false;
            // 
            // d110
            // 
            this.d110.BackColor = System.Drawing.Color.Lime;
            this.d110.Location = new System.Drawing.Point(12, 460);
            this.d110.Name = "d110";
            this.d110.Size = new System.Drawing.Size(50, 50);
            this.d110.TabIndex = 35;
            this.d110.TabStop = false;
            // 
            // d111
            // 
            this.d111.BackColor = System.Drawing.Color.Lime;
            this.d111.Location = new System.Drawing.Point(68, 460);
            this.d111.Name = "d111";
            this.d111.Size = new System.Drawing.Size(50, 50);
            this.d111.TabIndex = 36;
            this.d111.TabStop = false;
            // 
            // d120
            // 
            this.d120.BackColor = System.Drawing.Color.Lime;
            this.d120.Location = new System.Drawing.Point(12, 516);
            this.d120.Name = "d120";
            this.d120.Size = new System.Drawing.Size(50, 50);
            this.d120.TabIndex = 37;
            this.d120.TabStop = false;
            // 
            // d121
            // 
            this.d121.BackColor = System.Drawing.Color.Lime;
            this.d121.Location = new System.Drawing.Point(68, 516);
            this.d121.Name = "d121";
            this.d121.Size = new System.Drawing.Size(50, 50);
            this.d121.TabIndex = 38;
            this.d121.TabStop = false;
            // 
            // d221
            // 
            this.d221.BackColor = System.Drawing.Color.Lime;
            this.d221.Location = new System.Drawing.Point(897, 516);
            this.d221.Name = "d221";
            this.d221.Size = new System.Drawing.Size(50, 50);
            this.d221.TabIndex = 78;
            this.d221.TabStop = false;
            // 
            // d220
            // 
            this.d220.BackColor = System.Drawing.Color.Lime;
            this.d220.Location = new System.Drawing.Point(841, 516);
            this.d220.Name = "d220";
            this.d220.Size = new System.Drawing.Size(50, 50);
            this.d220.TabIndex = 77;
            this.d220.TabStop = false;
            // 
            // d211
            // 
            this.d211.BackColor = System.Drawing.Color.Lime;
            this.d211.Location = new System.Drawing.Point(897, 460);
            this.d211.Name = "d211";
            this.d211.Size = new System.Drawing.Size(50, 50);
            this.d211.TabIndex = 76;
            this.d211.TabStop = false;
            // 
            // d210
            // 
            this.d210.BackColor = System.Drawing.Color.Lime;
            this.d210.Location = new System.Drawing.Point(841, 460);
            this.d210.Name = "d210";
            this.d210.Size = new System.Drawing.Size(50, 50);
            this.d210.TabIndex = 75;
            this.d210.TabStop = false;
            // 
            // c222
            // 
            this.c222.BackColor = System.Drawing.Color.Lime;
            this.c222.Location = new System.Drawing.Point(953, 404);
            this.c222.Name = "c222";
            this.c222.Size = new System.Drawing.Size(50, 50);
            this.c222.TabIndex = 74;
            this.c222.TabStop = false;
            // 
            // c221
            // 
            this.c221.BackColor = System.Drawing.Color.Lime;
            this.c221.Location = new System.Drawing.Point(897, 404);
            this.c221.Name = "c221";
            this.c221.Size = new System.Drawing.Size(50, 50);
            this.c221.TabIndex = 73;
            this.c221.TabStop = false;
            // 
            // c220
            // 
            this.c220.BackColor = System.Drawing.Color.Lime;
            this.c220.Location = new System.Drawing.Point(841, 404);
            this.c220.Name = "c220";
            this.c220.Size = new System.Drawing.Size(50, 50);
            this.c220.TabIndex = 72;
            this.c220.TabStop = false;
            // 
            // c212
            // 
            this.c212.BackColor = System.Drawing.Color.Lime;
            this.c212.Location = new System.Drawing.Point(953, 348);
            this.c212.Name = "c212";
            this.c212.Size = new System.Drawing.Size(50, 50);
            this.c212.TabIndex = 71;
            this.c212.TabStop = false;
            // 
            // c211
            // 
            this.c211.BackColor = System.Drawing.Color.Lime;
            this.c211.Location = new System.Drawing.Point(897, 348);
            this.c211.Name = "c211";
            this.c211.Size = new System.Drawing.Size(50, 50);
            this.c211.TabIndex = 70;
            this.c211.TabStop = false;
            // 
            // c210
            // 
            this.c210.BackColor = System.Drawing.Color.Lime;
            this.c210.Location = new System.Drawing.Point(841, 348);
            this.c210.Name = "c210";
            this.c210.Size = new System.Drawing.Size(50, 50);
            this.c210.TabIndex = 69;
            this.c210.TabStop = false;
            // 
            // s223
            // 
            this.s223.BackColor = System.Drawing.Color.Lime;
            this.s223.Location = new System.Drawing.Point(1009, 292);
            this.s223.Name = "s223";
            this.s223.Size = new System.Drawing.Size(50, 50);
            this.s223.TabIndex = 68;
            this.s223.TabStop = false;
            // 
            // s222
            // 
            this.s222.BackColor = System.Drawing.Color.Lime;
            this.s222.Location = new System.Drawing.Point(953, 292);
            this.s222.Name = "s222";
            this.s222.Size = new System.Drawing.Size(50, 50);
            this.s222.TabIndex = 67;
            this.s222.TabStop = false;
            // 
            // s221
            // 
            this.s221.BackColor = System.Drawing.Color.Lime;
            this.s221.Location = new System.Drawing.Point(897, 292);
            this.s221.Name = "s221";
            this.s221.Size = new System.Drawing.Size(50, 50);
            this.s221.TabIndex = 66;
            this.s221.TabStop = false;
            // 
            // s213
            // 
            this.s213.BackColor = System.Drawing.Color.Lime;
            this.s213.Location = new System.Drawing.Point(1009, 236);
            this.s213.Name = "s213";
            this.s213.Size = new System.Drawing.Size(50, 50);
            this.s213.TabIndex = 65;
            this.s213.TabStop = false;
            // 
            // s212
            // 
            this.s212.BackColor = System.Drawing.Color.Lime;
            this.s212.Location = new System.Drawing.Point(953, 236);
            this.s212.Name = "s212";
            this.s212.Size = new System.Drawing.Size(50, 50);
            this.s212.TabIndex = 64;
            this.s212.TabStop = false;
            // 
            // s211
            // 
            this.s211.BackColor = System.Drawing.Color.Lime;
            this.s211.Location = new System.Drawing.Point(897, 236);
            this.s211.Name = "s211";
            this.s211.Size = new System.Drawing.Size(50, 50);
            this.s211.TabIndex = 63;
            this.s211.TabStop = false;
            // 
            // s220
            // 
            this.s220.BackColor = System.Drawing.Color.Lime;
            this.s220.Location = new System.Drawing.Point(841, 292);
            this.s220.Name = "s220";
            this.s220.Size = new System.Drawing.Size(50, 50);
            this.s220.TabIndex = 62;
            this.s220.TabStop = false;
            // 
            // s210
            // 
            this.s210.BackColor = System.Drawing.Color.Lime;
            this.s210.Location = new System.Drawing.Point(841, 236);
            this.s210.Name = "s210";
            this.s210.Size = new System.Drawing.Size(50, 50);
            this.s210.TabIndex = 61;
            this.s210.TabStop = false;
            // 
            // f223
            // 
            this.f223.BackColor = System.Drawing.Color.Lime;
            this.f223.Location = new System.Drawing.Point(1009, 180);
            this.f223.Name = "f223";
            this.f223.Size = new System.Drawing.Size(50, 50);
            this.f223.TabIndex = 60;
            this.f223.TabStop = false;
            // 
            // f222
            // 
            this.f222.BackColor = System.Drawing.Color.Lime;
            this.f222.Location = new System.Drawing.Point(953, 180);
            this.f222.Name = "f222";
            this.f222.Size = new System.Drawing.Size(50, 50);
            this.f222.TabIndex = 59;
            this.f222.TabStop = false;
            // 
            // f224
            // 
            this.f224.BackColor = System.Drawing.Color.Lime;
            this.f224.Location = new System.Drawing.Point(1065, 180);
            this.f224.Name = "f224";
            this.f224.Size = new System.Drawing.Size(50, 50);
            this.f224.TabIndex = 58;
            this.f224.TabStop = false;
            // 
            // f221
            // 
            this.f221.BackColor = System.Drawing.Color.Lime;
            this.f221.Location = new System.Drawing.Point(897, 180);
            this.f221.Name = "f221";
            this.f221.Size = new System.Drawing.Size(50, 50);
            this.f221.TabIndex = 57;
            this.f221.TabStop = false;
            // 
            // f220
            // 
            this.f220.BackColor = System.Drawing.Color.Lime;
            this.f220.Location = new System.Drawing.Point(841, 180);
            this.f220.Name = "f220";
            this.f220.Size = new System.Drawing.Size(50, 50);
            this.f220.TabIndex = 56;
            this.f220.TabStop = false;
            // 
            // f214
            // 
            this.f214.BackColor = System.Drawing.Color.Lime;
            this.f214.Location = new System.Drawing.Point(1065, 124);
            this.f214.Name = "f214";
            this.f214.Size = new System.Drawing.Size(50, 50);
            this.f214.TabIndex = 55;
            this.f214.TabStop = false;
            // 
            // f213
            // 
            this.f213.BackColor = System.Drawing.Color.Lime;
            this.f213.Location = new System.Drawing.Point(1009, 124);
            this.f213.Name = "f213";
            this.f213.Size = new System.Drawing.Size(50, 50);
            this.f213.TabIndex = 54;
            this.f213.TabStop = false;
            // 
            // f212
            // 
            this.f212.BackColor = System.Drawing.Color.Lime;
            this.f212.Location = new System.Drawing.Point(953, 124);
            this.f212.Name = "f212";
            this.f212.Size = new System.Drawing.Size(50, 50);
            this.f212.TabIndex = 53;
            this.f212.TabStop = false;
            // 
            // f211
            // 
            this.f211.BackColor = System.Drawing.Color.Lime;
            this.f211.Location = new System.Drawing.Point(897, 124);
            this.f211.Name = "f211";
            this.f211.Size = new System.Drawing.Size(50, 50);
            this.f211.TabIndex = 52;
            this.f211.TabStop = false;
            // 
            // f210
            // 
            this.f210.BackColor = System.Drawing.Color.Lime;
            this.f210.Location = new System.Drawing.Point(841, 124);
            this.f210.Name = "f210";
            this.f210.Size = new System.Drawing.Size(50, 50);
            this.f210.TabIndex = 51;
            this.f210.TabStop = false;
            // 
            // p225
            // 
            this.p225.BackColor = System.Drawing.Color.Lime;
            this.p225.Location = new System.Drawing.Point(1121, 68);
            this.p225.Name = "p225";
            this.p225.Size = new System.Drawing.Size(50, 50);
            this.p225.TabIndex = 50;
            this.p225.TabStop = false;
            // 
            // p224
            // 
            this.p224.BackColor = System.Drawing.Color.Lime;
            this.p224.Location = new System.Drawing.Point(1065, 68);
            this.p224.Name = "p224";
            this.p224.Size = new System.Drawing.Size(50, 50);
            this.p224.TabIndex = 49;
            this.p224.TabStop = false;
            // 
            // p223
            // 
            this.p223.BackColor = System.Drawing.Color.Lime;
            this.p223.Location = new System.Drawing.Point(1009, 68);
            this.p223.Name = "p223";
            this.p223.Size = new System.Drawing.Size(50, 50);
            this.p223.TabIndex = 48;
            this.p223.TabStop = false;
            // 
            // p222
            // 
            this.p222.BackColor = System.Drawing.Color.Lime;
            this.p222.Location = new System.Drawing.Point(953, 68);
            this.p222.Name = "p222";
            this.p222.Size = new System.Drawing.Size(50, 50);
            this.p222.TabIndex = 47;
            this.p222.TabStop = false;
            // 
            // p221
            // 
            this.p221.BackColor = System.Drawing.Color.Lime;
            this.p221.Location = new System.Drawing.Point(897, 68);
            this.p221.Name = "p221";
            this.p221.Size = new System.Drawing.Size(50, 50);
            this.p221.TabIndex = 46;
            this.p221.TabStop = false;
            // 
            // p220
            // 
            this.p220.BackColor = System.Drawing.Color.Lime;
            this.p220.Location = new System.Drawing.Point(841, 68);
            this.p220.Name = "p220";
            this.p220.Size = new System.Drawing.Size(50, 50);
            this.p220.TabIndex = 45;
            this.p220.TabStop = false;
            // 
            // p215
            // 
            this.p215.BackColor = System.Drawing.Color.Lime;
            this.p215.Location = new System.Drawing.Point(1121, 12);
            this.p215.Name = "p215";
            this.p215.Size = new System.Drawing.Size(50, 50);
            this.p215.TabIndex = 44;
            this.p215.TabStop = false;
            // 
            // p214
            // 
            this.p214.BackColor = System.Drawing.Color.Lime;
            this.p214.Location = new System.Drawing.Point(1065, 12);
            this.p214.Name = "p214";
            this.p214.Size = new System.Drawing.Size(50, 50);
            this.p214.TabIndex = 43;
            this.p214.TabStop = false;
            // 
            // p213
            // 
            this.p213.BackColor = System.Drawing.Color.Lime;
            this.p213.Location = new System.Drawing.Point(1009, 12);
            this.p213.Name = "p213";
            this.p213.Size = new System.Drawing.Size(50, 50);
            this.p213.TabIndex = 42;
            this.p213.TabStop = false;
            // 
            // p212
            // 
            this.p212.BackColor = System.Drawing.Color.Lime;
            this.p212.Location = new System.Drawing.Point(953, 12);
            this.p212.Name = "p212";
            this.p212.Size = new System.Drawing.Size(50, 50);
            this.p212.TabIndex = 41;
            this.p212.TabStop = false;
            // 
            // p211
            // 
            this.p211.BackColor = System.Drawing.Color.Lime;
            this.p211.Location = new System.Drawing.Point(897, 12);
            this.p211.Name = "p211";
            this.p211.Size = new System.Drawing.Size(50, 50);
            this.p211.TabIndex = 40;
            this.p211.TabStop = false;
            // 
            // p210
            // 
            this.p210.BackColor = System.Drawing.Color.Lime;
            this.p210.Location = new System.Drawing.Point(841, 12);
            this.p210.Name = "p210";
            this.p210.Size = new System.Drawing.Size(50, 50);
            this.p210.TabIndex = 39;
            this.p210.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(518, 35);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 50);
            this.button1.TabIndex = 79;
            this.button1.Text = "Simular";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // listaJugador2
            // 
            this.listaJugador2.FormattingEnabled = true;
            this.listaJugador2.ItemHeight = 16;
            this.listaJugador2.Location = new System.Drawing.Point(345, 139);
            this.listaJugador2.Name = "listaJugador2";
            this.listaJugador2.Size = new System.Drawing.Size(222, 436);
            this.listaJugador2.TabIndex = 81;
            // 
            // listaJugador1
            // 
            this.listaJugador1.FormattingEnabled = true;
            this.listaJugador1.ItemHeight = 16;
            this.listaJugador1.Location = new System.Drawing.Point(598, 139);
            this.listaJugador1.Name = "listaJugador1";
            this.listaJugador1.Size = new System.Drawing.Size(226, 436);
            this.listaJugador1.TabIndex = 82;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(821, 627);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 25);
            this.label1.TabIndex = 83;
            this.label1.Text = "Barcos Jugador 2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(63, 636);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(182, 25);
            this.label2.TabIndex = 84;
            this.label2.Text = "Barcos Jugador 1";
            // 
            // BatallaNavalModoSemiautomatico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1194, 680);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listaJugador1);
            this.Controls.Add(this.listaJugador2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.d221);
            this.Controls.Add(this.d220);
            this.Controls.Add(this.d211);
            this.Controls.Add(this.d210);
            this.Controls.Add(this.c222);
            this.Controls.Add(this.c221);
            this.Controls.Add(this.c220);
            this.Controls.Add(this.c212);
            this.Controls.Add(this.c211);
            this.Controls.Add(this.c210);
            this.Controls.Add(this.s223);
            this.Controls.Add(this.s222);
            this.Controls.Add(this.s221);
            this.Controls.Add(this.s213);
            this.Controls.Add(this.s212);
            this.Controls.Add(this.s211);
            this.Controls.Add(this.s220);
            this.Controls.Add(this.s210);
            this.Controls.Add(this.f223);
            this.Controls.Add(this.f222);
            this.Controls.Add(this.f224);
            this.Controls.Add(this.f221);
            this.Controls.Add(this.f220);
            this.Controls.Add(this.f214);
            this.Controls.Add(this.f213);
            this.Controls.Add(this.f212);
            this.Controls.Add(this.f211);
            this.Controls.Add(this.f210);
            this.Controls.Add(this.p225);
            this.Controls.Add(this.p224);
            this.Controls.Add(this.p223);
            this.Controls.Add(this.p222);
            this.Controls.Add(this.p221);
            this.Controls.Add(this.p220);
            this.Controls.Add(this.p215);
            this.Controls.Add(this.p214);
            this.Controls.Add(this.p213);
            this.Controls.Add(this.p212);
            this.Controls.Add(this.p211);
            this.Controls.Add(this.p210);
            this.Controls.Add(this.d121);
            this.Controls.Add(this.d120);
            this.Controls.Add(this.d111);
            this.Controls.Add(this.d110);
            this.Controls.Add(this.c122);
            this.Controls.Add(this.c121);
            this.Controls.Add(this.c120);
            this.Controls.Add(this.c112);
            this.Controls.Add(this.c111);
            this.Controls.Add(this.c110);
            this.Controls.Add(this.s123);
            this.Controls.Add(this.s122);
            this.Controls.Add(this.s121);
            this.Controls.Add(this.s113);
            this.Controls.Add(this.s112);
            this.Controls.Add(this.s111);
            this.Controls.Add(this.s120);
            this.Controls.Add(this.s110);
            this.Controls.Add(this.f123);
            this.Controls.Add(this.f122);
            this.Controls.Add(this.f124);
            this.Controls.Add(this.f121);
            this.Controls.Add(this.f120);
            this.Controls.Add(this.f114);
            this.Controls.Add(this.f113);
            this.Controls.Add(this.f112);
            this.Controls.Add(this.f111);
            this.Controls.Add(this.f110);
            this.Controls.Add(this.p125);
            this.Controls.Add(this.p124);
            this.Controls.Add(this.p123);
            this.Controls.Add(this.p122);
            this.Controls.Add(this.p121);
            this.Controls.Add(this.p120);
            this.Controls.Add(this.p115);
            this.Controls.Add(this.p114);
            this.Controls.Add(this.p113);
            this.Controls.Add(this.p112);
            this.Controls.Add(this.p111);
            this.Controls.Add(this.p110);
            this.Name = "BatallaNavalModoSemiautomatico";
            this.Text = "BatallaNavalModoSemiautomatico";
            ((System.ComponentModel.ISupportInitialize)(this.p110)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p111)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p112)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p113)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p114)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p115)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p120)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p121)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p122)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p123)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p124)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p125)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f110)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f111)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f112)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f113)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f114)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f120)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f121)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f124)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f122)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f123)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s110)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s120)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s111)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s112)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s113)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s121)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s122)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s123)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c110)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c111)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c112)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c120)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c121)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c122)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.d110)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.d111)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.d120)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.d121)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.d221)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.d220)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.d211)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.d210)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c222)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c221)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c220)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c212)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c211)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c210)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s223)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s222)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s221)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s213)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s212)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s211)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s220)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s210)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f223)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f222)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f224)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f221)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f220)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f214)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f213)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f212)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f211)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f210)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p225)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p224)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p223)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p222)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p221)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p220)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p215)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p214)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p213)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p212)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p211)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p210)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox p110;
        private System.Windows.Forms.PictureBox p111;
        private System.Windows.Forms.PictureBox p112;
        private System.Windows.Forms.PictureBox p113;
        private System.Windows.Forms.PictureBox p114;
        private System.Windows.Forms.PictureBox p115;
        private System.Windows.Forms.PictureBox p120;
        private System.Windows.Forms.PictureBox p121;
        private System.Windows.Forms.PictureBox p122;
        private System.Windows.Forms.PictureBox p123;
        private System.Windows.Forms.PictureBox p124;
        private System.Windows.Forms.PictureBox p125;
        private System.Windows.Forms.PictureBox f110;
        private System.Windows.Forms.PictureBox f111;
        private System.Windows.Forms.PictureBox f112;
        private System.Windows.Forms.PictureBox f113;
        private System.Windows.Forms.PictureBox f114;
        private System.Windows.Forms.PictureBox f120;
        private System.Windows.Forms.PictureBox f121;
        private System.Windows.Forms.PictureBox f124;
        private System.Windows.Forms.PictureBox f122;
        private System.Windows.Forms.PictureBox f123;
        private System.Windows.Forms.PictureBox s110;
        private System.Windows.Forms.PictureBox s120;
        private System.Windows.Forms.PictureBox s111;
        private System.Windows.Forms.PictureBox s112;
        private System.Windows.Forms.PictureBox s113;
        private System.Windows.Forms.PictureBox s121;
        private System.Windows.Forms.PictureBox s122;
        private System.Windows.Forms.PictureBox s123;
        private System.Windows.Forms.PictureBox c110;
        private System.Windows.Forms.PictureBox c111;
        private System.Windows.Forms.PictureBox c112;
        private System.Windows.Forms.PictureBox c120;
        private System.Windows.Forms.PictureBox c121;
        private System.Windows.Forms.PictureBox c122;
        private System.Windows.Forms.PictureBox d110;
        private System.Windows.Forms.PictureBox d111;
        private System.Windows.Forms.PictureBox d120;
        private System.Windows.Forms.PictureBox d121;
        private System.Windows.Forms.PictureBox d221;
        private System.Windows.Forms.PictureBox d220;
        private System.Windows.Forms.PictureBox d211;
        private System.Windows.Forms.PictureBox d210;
        private System.Windows.Forms.PictureBox c222;
        private System.Windows.Forms.PictureBox c221;
        private System.Windows.Forms.PictureBox c220;
        private System.Windows.Forms.PictureBox c212;
        private System.Windows.Forms.PictureBox c211;
        private System.Windows.Forms.PictureBox c210;
        private System.Windows.Forms.PictureBox s223;
        private System.Windows.Forms.PictureBox s222;
        private System.Windows.Forms.PictureBox s221;
        private System.Windows.Forms.PictureBox s213;
        private System.Windows.Forms.PictureBox s212;
        private System.Windows.Forms.PictureBox s211;
        private System.Windows.Forms.PictureBox s220;
        private System.Windows.Forms.PictureBox s210;
        private System.Windows.Forms.PictureBox f223;
        private System.Windows.Forms.PictureBox f222;
        private System.Windows.Forms.PictureBox f224;
        private System.Windows.Forms.PictureBox f221;
        private System.Windows.Forms.PictureBox f220;
        private System.Windows.Forms.PictureBox f214;
        private System.Windows.Forms.PictureBox f213;
        private System.Windows.Forms.PictureBox f212;
        private System.Windows.Forms.PictureBox f211;
        private System.Windows.Forms.PictureBox f210;
        private System.Windows.Forms.PictureBox p225;
        private System.Windows.Forms.PictureBox p224;
        private System.Windows.Forms.PictureBox p223;
        private System.Windows.Forms.PictureBox p222;
        private System.Windows.Forms.PictureBox p221;
        private System.Windows.Forms.PictureBox p220;
        private System.Windows.Forms.PictureBox p215;
        private System.Windows.Forms.PictureBox p214;
        private System.Windows.Forms.PictureBox p213;
        private System.Windows.Forms.PictureBox p212;
        private System.Windows.Forms.PictureBox p211;
        private System.Windows.Forms.PictureBox p210;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox listaJugador2;
        private System.Windows.Forms.ListBox listaJugador1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}